const { urlencoded } = require('express');
const express=require('express');
const jwt=require('jsonwebtoken');
const mongoose=require('mongoose');
const dotenv=require('dotenv');
const morgan=require('morgan');
const app=express();

const PORT=process.env.PORT || 5001

const url='mongodb+srv://hello123:hello123@cluster0.w3rxy.mongodb.net/?retryWrites=true&w=majority'

//Mongoose Connection
mongoose.connect(url,{useNewUrlParser:true})
const con=mongoose.connection
con.on('open',()=>{
    console.log("connected")
})
app.use(express.json())
const todoRouter=require('./routes/todoList')
app.use('/todoList',todoRouter);


//JWT 
//Validate JWT
app.post('/user/validateToken',verifyToken,(req,res)=>{
    jwt.verify(req.token,'secretkey',(err,authData)=>{
        if(err){
            res.sendStatus(403);
        }else{
            res.json({
                message:"post created",
                authData
            })
        }
    })
})

//Generate Token
app.post('/user/generateToken',(req,res)=>{
    const user={
        id:1,
        username:'hello',
        email:'hello@gmail.com'
    }
    jwt.sign({user},'secretkey',(err,token)=>{
        res.json({
            token
        });
    });
});
function verifyToken(req,res,next){
    const bearerHeader=req.headers['authorization'];
    if(typeof bearerHeader !== 'undefined'){
        const bearer=bearerHeader.split(' ');
        const bearerToken=bearer[1];
        req.token=bearerToken;
        next();
    }else{
        res.sendStatus(403)
    }
}
app.listen(PORT,()=>console.log('server is up 5000'))