const express=require('express');
const router=express.Router();
const Todo=require('../models/todoList')

//Read
router.get('/showTodo',async(req,res)=>{
    try{
        const todo=await Todo.find()
        res.json(todo)
    }catch(error){
        res.send('Error '+error)
    }
})
router.get('/showTodo/:id',async(req,res)=>{
    try{
        const todo=await Todo.findById(req.params.id)
        res.json(todo)
    }catch(error){
        res.send('Error '+error)
    }
})

//Create
router.post('/addTodo',async(req,res)=>{
    const todo=new Todo({
        title:req.body.title
    })
    try{
       const a1= await todo.save()
       res.json(a1)
    }catch(error){
        res.send('Error '+error)
    }
})

//Update
router.patch('/update/:id',async(req,res)=>{
    try{
        const todo= await Todo.findById(req.params.id)
        todo.title=req.body.title
        const a1=await todo.save()
        res.json(a1)
    }catch(error){
        res.send('Error '+error)
    }
})

//Delete
router.delete('/delete/:id',async(req,res)=>{
    try{
        const todo= await Todo.findById(req.params.id)
        todo.title=req.body.title
        const a1=await todo.remove()
        res.json('Item Deleted')
    }catch(error){
        res.send('Error '+error)
    }
})

module.exports=router